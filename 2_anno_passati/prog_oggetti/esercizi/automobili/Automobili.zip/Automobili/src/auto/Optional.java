package auto;

/**
 * Classe rappresenta un optional di una auto.
 * Un optional e' identificato univocamente dal suo codice, ha un valore commerciale
 * e una descrizione simbolica.
 * @author Mariachiara Puviani
 */
public class Optional
{

    /**
     * Codice univoco dell'optional.
     */
    private int codice;   

    /**
     * Descrizione dell'optional.
     */
    private String descrizione;

    /**
     * Valore commerciale dell'optional.
     */
    private int valore;

    /**
     * Costruttore.
     * E' necessario specificare il codice, la descrizione e il valore dell'optional. 
     * Se la descrizione non viene fornita viene messo un valore di default (DESCRIZIONE NON DISPONIBILE).
     * @param codice Il codice dell'optional
     * @param valore Il valore dell'optional
     * @param descrizione La descrizione dell'optional
     */
    public Optional(int codice, int valore, String descrizione)
    {
    	this.codice = codice;
		this.valore = valore;
		if(descrizione != null)
		{
		    this.descrizione = descrizione;
		}
		else
		{
		    this.descrizione = "DESCRIZIONE NON DISPONIBILE";
		}
    }

    /**
     * Metodo per cambiare la descrizione corrente.
     * @param descrizione La nuova descrizione dell'optional
     */
    public void setDescrizione(String descrizione)
    {
    	this.descrizione = descrizione;
    }

    /**
     * Metodo per ottenere il codice dell'optional.
     * @return iIl codice univoco dell'optional
     */
    public int getCodice()
    {
    	return codice;
    }

    /**
     * Metodo per ottenere la descrizione dell'optional.
     * @return La descrizione dell'optional
     */
    public String getDescrizione()
    {
    	return descrizione;
    }

    /**
     * Metodo per cambiare il valore dell'optional.
     * @param valore Il nuovo valore dell'optional
     */
    public void setValore(int valore)
    {
    	if(valore >= 0)
    	{
    		this.valore = valore;
    	}
    }

    /**
     * Metodo per ottenere il valore dell'optional.
     * @return Il valore commerciale dell'optional
     */
    public int getValore()
    {
    	return valore;
    }

    /**
     * Metodo invocato ogni volta che si usa l'operatore + a stringa su una istanza di
     * questo oggetto.
     * @return La stringa di descrizione di questo oggetto
     */
    public String toString()
    {
    	return "Optional <" + codice + "> : " + descrizione;
    }

}

