package auto;

import motori.*;

/**
 * Classe che deifinisce una automobile.
 * @author Mariachiara Puviani
 */
public class Automobile
{
    /**
     * Optional dell'auto
     */
    protected Optional optionals[];

    /**
     * Motore dell'auto
     */
    protected Motore motore;

    /**
     * Modello dell'auto
     */
    protected String modello;

    /**
     * Marca dell'auto
     */
    protected String marca;

    /**
     * Targa dell'auto
     */
    protected String targa;

    /**
     * Costruttore.
     * @param targa La targa dell'auto
     * @param marca La marca dell'auto
     * @param modello Il modello dell'auto
     * @param motore Il motore dell'auto
     */
    public Automobile(String targa, String marca, String modello, Motore motore)
    {
		this.marca = marca;
		this.targa = targa;
		this.modello = modello;
		this.motore = motore;
    }

    /**
     * Targa dell'auto.
     * @return La targa 
     */
    public String getTarga()
    {
    	return targa;
    }

    /**
     * Modello dell'auto
     * @return Il modello dell'auto
     */
    public String getModello()
    {
    	return modello;
    }

    /**
     * Marca dell'auto
     * @return La marca dell'auto
     */
    public String getMarca()
    {
    	return marca;
    }

    /**
     * Motore dell'auto.
     * @return L'oggetto di tipo motore montato sull'auto
     */
    public Motore getMotore()
    {
    	return motore;
    }

    /**
     * Cilindrata del motore.
     * Si noti che questo non e' un metodo get puro, in quanto ritorna il valore di
     * una variabile annidata (Motore.cilindrata), e quindi di questo metodo non comincia
     * con "get" (con get chiamiamo solo i metodi che restituiscono valori
     * di variabili di questa classe). 
     * E' sempre possibile risalire
     * alla cilindrata dal motore anche con getMotore()).getCilindrata(), ma definire
     * un metodo "wrapper" per la cilindrata anche nella classe automobile puo' avere
     * senso per questioni di praticita' ed interfaccia.
     * @return La cilindrata del motore
     */
    public int cilindrata()
    {
    	return motore.getCilindrata();	
    }

    /**
     * Tipo dell'autmobile.
     * ATTENZIONE: il tipo primitivo boolean non avrebbe accettato un valore null,
     * a differenza di un oggetto di tipo Boolean.
     * @return True se coup�, false altrimenti, null se l'informazione non � disponibile
     */
    public Boolean isCoupe()
    {
    	return null;
    }

    /**
     * Metodo per aggiungere un optional. 
     * Copia l'array esistente di 
     * optional in un array piu' grande e aggiunge l'otpional.
     * @param Optional (oggetto) da aggiungere
     */
    public void aggiungiOptional(Optional opt)
    {
		// se non ci sono optional creo un nuovo array
		if( optionals == null )
		{
		    optionals = new Optional[1];
		    optionals[0] = opt;
		    return;
		}
		// creo un array temporaneo
		Optional tmp[] = new Optional[optionals.length+1];
		System.arraycopy(optionals,0,tmp,0,optionals.length);
		tmp[tmp.length-1] = opt;
		optionals = tmp;
    }

    /**
     * Metodo per analizzare i vari optional.
     * @return La lista degli optional
     */
    public Optional[] getOptionals()
    {
    	return optionals;
    }


}
