package auto;

import motori.*;

/**
 * Classe che rappresenta una coupe'.
 * @author Mariachiara Puviani
 */
public class Coupe extends Automobile
{
    /**
     * Costruttore.
     * @param targa La targa dell'auto
     * @param marca La marca dell'auto
     * @param modello Il modello dell'auto
     * @param motore Il motore dell'auto
     */
    public Coupe(String targa, String marca, String modello, Motore motore)
    {
    	super(targa,marca,modello,motore);
    }
    
     /**
     * Tipo dell'autmobile.
     * @return True (perch� � una coupe')
     */
    public Boolean isCoupe()
    {
    	Boolean b = new Boolean(true);
    	return b;
    }
}
