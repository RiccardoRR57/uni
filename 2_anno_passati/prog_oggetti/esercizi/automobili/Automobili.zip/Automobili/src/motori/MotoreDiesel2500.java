package motori;

/**
 * Classe che rappresenta un motore diesel di 2500 cc.
 * @author Mariachiara Puviani
 */
public class MotoreDiesel2500 extends MotoreDiesel
{
    /**
     * Costruttore.
     * Tutti i dati di inizializzazione sono codificati direttamente nella classe MotoreDiesel.
     */
    public MotoreDiesel2500()
    {
    	super(2500,6,5000);
    }
}
