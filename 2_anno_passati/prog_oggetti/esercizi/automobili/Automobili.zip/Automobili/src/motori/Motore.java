package motori;

/**
 * Classe base per una gerarchia di motori, che rappresenta un generico motore.
 * Siccome questa classe non puo' implementare alcuni metodi troppo specifici 
 * (ossia troppo legati al motore stesso)
 * la classe Motore viene definita come astratta. 
 * Definisce l'interfaccia che ogni motore deve avere
 * e obbliga i veicoli a fornire una implementazione dei metodi astratti. 
 * Inoltre non � possibile ottenere una istanza
 * di un motore, ma solo ad una sua sottoclasse 
 * (cio' non significa che non sia possibile riferirsi ad istanza come ad un motore).
 * @author Mariachiara Puviani
 */
public abstract class Motore
{
    /**
     * La cilindrata del motore.
     */
    protected int cilindrata;
    /**
     * Cavalli del motore.
     */
    protected  int cavalli;
    /**
     * Numero di cilindri del motore.
     */
    protected  int cilindri;

    /**
     * Costruttore. 
     * NB: Una classe astratta puo' avere 
     * i costruttori come una classe normale.
     * @param cilindrata La cilindrata del motore
     * @param cilindri Il numero di cilindri del motore.
     */
    public Motore(int cilindrata, int cilindri)
    {
    	this.cilindrata = cilindrata;
    	this.cilindri = cilindri;
    	// i cavalli vapore dipendono dalla cilindrata e dal numero di cilindro
    	this.cavalli = potenza();
    }


    /**
     * Metodo che indica se il motore e' diesel o benzina.
     * @return True se il motore e' diesel, false se e' benzina.
     */
    public abstract boolean isDiesel();

    /**
     * Metodo che calcola e restituisce il numero massimo di giri al minuto.
     * @return Il numero massimo di giri al minuto (RPM).
     */
    public abstract int maxRPM();

    /**
     * Metodo che calcola la potenza del motore.
     * @return La potenza del motore.
     */
    public abstract int potenza();

    /** 
     * Metodo che calcola la cilindrata del motore.
     * @return La cilindrata del motore
     */
    public int getCilindrata(){
	return cilindrata;
    }

}

