package motori;

/**
 * Classe che rappresenta un motore benzina di 3000 cc.
 * @author Mariachiara Puviani
 */
public class MotoreBenzina3000 extends MotoreBenzina
{
    /**
     * Costruttore.
     * Tutti i dati di inizializzazione sono codificati direttamente nella classe MotoreBenzina.
     */
    public MotoreBenzina3000()
    {
    	super(3000,6);
    }
}
