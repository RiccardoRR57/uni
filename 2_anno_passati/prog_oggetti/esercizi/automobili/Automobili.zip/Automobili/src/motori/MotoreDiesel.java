package motori;

/**
 * Classe che rappresenta un motore diesel.
 * @author Mariachiara Puviani
 */
public class MotoreDiesel extends Motore
{

    protected int maxRPM;

    /**
     * Costruttore: necessita dei dati di inizializzazione della classe base (Motore) e
     * dei dati (eventuali) di inizializzazione di questa classe.
     * @param cilindrata La cilindrata del motore
     * @param cilindri Il numero di cilindri del motore
     * @param maxRPM Numero massimo di giri al minuto
     */
    public MotoreDiesel(int cilindrata, int cilindri, int maxRPM)
    {
    	super(cilindrata, cilindri);
    	this.maxRPM = maxRPM;
    }

    /** 
     * Calcolo della potenza del motore.
     * @return La potenza del motore
     */
    public final int potenza()
    {
    	return (this.cilindrata/this.cilindri)/20;
    }

    /**
     * Calcolo del numero massimo di giri al minuto del motore.
     * @return Numero massimo di giri minuto
     */
    public int maxRPM()
    {
    	return maxRPM;
    }

    /**
     * Indica se il motore e' diesel.
     * @return True (perch� il motore � diesel
     */
    public final boolean isDiesel()
    {
    	return true;
    }
}
