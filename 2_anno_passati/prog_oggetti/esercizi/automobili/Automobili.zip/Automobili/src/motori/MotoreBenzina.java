package motori;

/**
 * Classe che rappresenta un motore a benzina.
 * @author Mariachiara Puviani
 */
public class MotoreBenzina extends Motore
{

    /**
     * Costruttore: necessita dei dati di inizializzazione della classe base (Motore) e
     * dei dati (eventuali) di inizializzazione propri della classe.
     * @param cilindrata La cilindrata del motore
     * @param cilindri Il numero di cilindri del motore
     */
    public MotoreBenzina(int cilindrata, int cilindri)
    {
    	// Richiamo il costruttore della classe base Motore
    	super(cilindrata, cilindri);
    }

    /** 
     * Calcolo della potenza del motore.
     * @return La potenza del motore
     */
    public final int potenza()
    {
    	return (this.cilindrata/this.cilindri)/10;
    }

    /**
     * Calcolo del numero massimo di giri al minuto.
     * @return Numero massimo di giri minuto
     */
    public int maxRPM()
    {
    	return 7500;
    }

    /**
     * Indica se il motore e' diesel.
     * @return False (perch� � un motore benzina)
     */
    public final boolean isDiesel()
    {
    	return false;
    }
}
