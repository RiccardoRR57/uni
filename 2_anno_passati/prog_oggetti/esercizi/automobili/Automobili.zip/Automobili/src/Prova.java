import auto.*;
import motori.*;

/**
 * Programma di esempio di utilizzo delle classi auto/motori
 */
public class Prova
{
    public static void main(String argv[])
    {
		// Creo degli optionals
		Optional op1 = new Optional(1234, 200, "Vetri elettrici");
		Optional op2 = new Optional(77, 1000, "Aria condizionata");
		Optional op3 = new Optional(78, 2000, "Climatizzatore automatico");
		Optional op4 = new Optional(90, 500, "Caricatore CD");
	
		// Creo un array di automobili generiche
		Automobile auto[] = new Automobile[5];
		// Definisco le singole automobili
		auto[0] = new Berlina("MO 123456789", "BMW", "M3", new MotoreBenzina3000());
		auto[1] = new Berlina("BO 987654321", "MERCEDES", "S", new MotoreDiesel2500());
		auto[2] = new Coupe("RA 33333333", "FIAT", "Punto", new MotoreBenzina(1200,4));
		auto[3] = new Coupe("MI 7777777", "Audi", "A4", new MotoreDiesel(1800,4,100));
		auto[4] = new Automobile("RE 8888888", "FIAT", "Seicento", new MotoreBenzina(1000,4));
		// Aggiungo gli optional
		auto[0].aggiungiOptional(op1);
		auto[0].aggiungiOptional(op2);
		auto[3].aggiungiOptional(op3);
		auto[3].aggiungiOptional(op4);
	
		// Stampo le caratteristiche delle auto
		for(int i=0;i<auto.length;i++)
		{
		    System.out.println("\nAuto " + (i+1));
		    System.out.println("Targa: " + auto[i].getTarga());
		    System.out.println("Modello: " + auto[i].getModello());
		    System.out.println("Coupe': " + auto[i].isCoupe());
		    
		    // Definisco un oggetto Motore che punta ogni volta alla classe concreta
		    Motore mot = auto[i].getMotore();
		    System.out.println("Cilindrata = " + mot.getCilindrata());
		    System.out.println("Potenza = " + mot.potenza());
		    System.out.println("Diesel = " + mot.isDiesel());
		    
		    // Prelevo gli optional
		    Optional[] opts = auto[i].getOptionals();
		    if (opts!=null)
		    {
		    	for(int j=0; j<opts.length; j++)
		    	{
		    		System.out.println(j+1 + ". " + opts[j]);
		    	}
		    }   
		}
    }
}
