package figure;

/**
 * Classe che definisce un quadrato
 * eredita dalla classe Rettangolo
 * @author mariachiarapuviani
 *
 */
public class Quadrato extends Rettangolo 
{

	/**
	 * Costruttore
	 * @param lato Lato del quadrato
	 */
   public Quadrato(int lato) 
   {
	   // Richiamo il costruttore della classe rettangolo
	   super(lato, lato); 
   }
   
   /**
    * Metodo per ottenere il lato
    * @return Il lato del quadrato
    */
   public double getLato() 
   { 
	   return getBase(); 
   }
}