package figure;

/**
 * Classe che rappresenta un triangolo
 * @author mariachiarapuviani
 *
 */
   public class Triangolo extends Figura 
   {
	   /**
	    * Base del triangolo
	    */
       private double base;
       /**
        * Altezza del triangolo
        */
       private double altezza;
       //se definisco le var protected non ho bisogno dei metodi get/set ma le posso recuperare con this.
       /**
        * Cateto 1 del triangolo
        */
       protected double cateto1;
       /**
        * Cateto 2 del triangolo
        */
       protected double cateto2;

       /**
        * Costruttore
        * @param base La base del triangolo
        * @param altezza L'altezza del triangolo
        * @param cateto1 Il cateto 1 del triangolo
        * @param cateto2 Il cateto 2 dl triangolo
        */
       public Triangolo(double base, double altezza, double cateto1, double cateto2) 
       {
          this.base = base;
          this.altezza = altezza;
          this.cateto1 = cateto1;
          this.cateto2 = cateto2;
       }
       
       public double calcolaArea() 
       { 
    	   return (base * altezza) / 2; 
       }
       public double calcolaPerimetro(){
    	   return (base + cateto2 + cateto1);
       }
       
       /**
        * Metodo per ottenere la base
        * @return La base del triangolo
        */
       public double getBase() 
       { 
    	   return this.base; 
       }
       /**
        * Metodo per settare la base
        * @param base La base del triangolo
        */
       public void setBase(double base)
       {
    	   this.base = base;
       }
       /**
        * Metodo per ottenere l'altezza
        * @return L'altezza del triangolo
        */
       public double getAltezza() 
       { 
    	   return this.altezza; 
       }
       /**
        * Metodo per settare l'altezza
        * @param altezza L'altezza del triangolo
        */
       public void setAltezza(double altezza)
       {
    	   this.altezza = altezza;
       }
    }