package figure;

/**
 * Classe che definisce un rettangolo
 * @author mariachiarapuviani
 *
 */
public class Rettangolo extends Figura 
{
	/** 
	 * Base del rettangolo
	 */
	private double base;
	/**
	 * Altezza del rettangolo
	 */
	private double altezza;

   /**
    * Costruttore
    * @param base La base del rettangolo
    * @param altezza L'altezza del rettangolo
    */ 
   public Rettangolo(double base, double altezza) 
   {
      this.base = base;
      this.altezza = altezza;
   }


   public double calcolaArea() 
   { 
	   return (base * altezza); 
   }
   public double calcolaPerimetro() 
   {
	   return (base * 2 + altezza * 2);
   }
   
   
   //Avrei potuto evitare questi metodi mettendo protected le variabili base e altezza
   /**
    * Metodo per ottenere la base del rettnagolo
    * @ return La base del rettangolo
    */
   public double getBase() 
   { 
	   return this.base; 
   }
   /**
    * Metodo per settare la base del rettangolo
    * @param base La base del rettangolo
    */
   public void setBase(double base)
   {
	   this.base = base;
   }
   /**
    * Metodo per ottenere l'altezza del rettangolo
    * @return L'altezza del rettangolo
    */
   public double getAltezza() 
   { 
	   return this.altezza; 
   }
   /**
    * Metodo per settare l'altezza del rettangolo
    * @param altezza L'altezza del rettangolo
    */
   public void setAltezza(double altezza)
   {
	   this.altezza = altezza;
   }
}
