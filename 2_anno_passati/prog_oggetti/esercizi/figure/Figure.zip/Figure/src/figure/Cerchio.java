package figure;

/** 
 * Classe che definisce un cerchio
 * @author mariachiarapuviani
 *
 */
public class Cerchio extends Figura 
{

	/**
	 * Raggio del cerchio
	 */
	protected double raggio;
	
	static final double PI = 3.1416;
	// al posto di creare questa costante avrei potuto importare il pakcage java.Math.*
	// che ha al suo interno la variabile PI
	// altrimenti tutte le volte che la uso (se non importo il package)
	// la richiamo con "Math.PI"
	
	/**
	 * Costruttore
	 */
	public Cerchio (double raggio)
	{
		this.raggio = raggio;
	}
	
	public double calcolaArea()
	{
		return (PI * raggio * raggio);
	}
	public double calcolaPerimetro()
	{
		return (2 * PI * raggio);
	}

}
