package figure;

/**
 * Classe che rappresenta un triangolo rettangolo
 * Eredita dalla classe triangolo
 * @author mariachiarapuviani
 *
 */
public class TriangoloRettangolo extends Triangolo
{
	/**
	 * Costruttore
	 * NB: i cateti solo calcolati automaticamente
	 * @param base La base del triangolo rettangolo
	 * @param altezza L'altezza del triangolo rettangolo
	 */
   public TriangoloRettangolo(double base, double altezza) 
   { 
	   // Richiamo il costruttore della classe triangolo
	   super(base, altezza, altezza,(Math.sqrt(base*base + altezza*altezza))); 
   }
   
   //Il calcolo dell'area rimane ugulae
   //Ridefinisco solo il calcolo del perimetro
   public double calcolaPerimetro()
   {
	   return (this.getBase() + this.getAltezza() + this.cateto1);
   }
}
