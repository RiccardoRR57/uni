package figure;

/**
 * Classe astratta che rappresenta una figura
 * @author mariachiarapuviani
 *
 */
public abstract class Figura 
{

	/** 
	 * Metodo per il calcolo dell'area
	 * @return L'area della figura
	 */
	public abstract double calcolaArea();
	/** 
	 * Metodo per il calcolo del perimetro
	 * @return Il perimetro della figura
	 */
	public abstract double calcolaPerimetro();
	
	/**
	 * Metodo per la stampa dei dati (area e perimetro)
	 */
	public void dati()
	{
		System.out.println("La figura ha area di " + calcolaArea() + " e perimetro di " + calcolaPerimetro());
	}
   
}
