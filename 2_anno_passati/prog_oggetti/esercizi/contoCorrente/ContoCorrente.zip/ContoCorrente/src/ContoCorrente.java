/**
 * Classe che implementa un semplice conto corrente bancario.
 */
public class ContoCorrente {

	// variabili interne della classe

	/**
	 * Numero di conto corrente.
	 */
	private int CCnum;

	/**
	 * Saldo attuale.
	 */
	private int saldo;

	/**
	 * ultimi movimenti effettuati sul conto.
	 */
	private int[] movimenti;

	/**
	 * conteggio del numero totale di movimenti.
	 */
	private int contMovim;

	/**
	 * Costruttore della classe. Inizializza il conto corrente con numero di
	 * conto e saldo di partenza.
	 * 
	 * @param CCnum 	numero di conto
	 * @param saldo		saldo iniziale
	 */
	public ContoCorrente(int CCnum, int saldo) {
		// inizializzazione campi CCnum e saldo
		this.CCnum = CCnum;
		this.saldo = saldo;

		// contMovim � inizializzato a 0 di default!

		// creo il vettore dei movimenti
		movimenti = new int[20];
	}

	/**
	 * Prelievo. Questo metodo simula un prelievo togliendo dal saldo corrente
	 * l'importo specificato.
	 * 
	 * @param importo	la quantita' da prelevare.
	 */
	public void prelievo(int importo) {
		saldo = saldo - importo;
		movimenti[contMovim++] = -importo;
		System.out.println("Effettuato un prelievo di " + importo
				+ " sul conto " + CCnum);
	}

	/**
	 * Versamento. Operazione opposta al prelievo.
	 * 
	 * @param importo	la quantita' da versare sul conto.
	 */
	public void versamento(int importo) {
		saldo = saldo + importo;
		movimenti[contMovim++] = importo;
		System.out.println("Effettuato un versamento di " + importo
				+ " sul conto " + CCnum);
	}

	/**
	 * Saldo corrente.
	 * 
	 * @return il saldo corrente.
	 */
	public int getSaldo() {
		return saldo;
	}

	/**
	 * Stampa su stdout la lista degli ultimi movimenti effettuati.
	 */
	public void stampaMovimenti() {
		System.out.println("La lista dei movimenti del Conto Corrente " + CCnum
				+ " e':");
		for (int i = 0; i < movimenti.length; i++) {
			System.out.println(movimenti[i]);
		}
	}
}

