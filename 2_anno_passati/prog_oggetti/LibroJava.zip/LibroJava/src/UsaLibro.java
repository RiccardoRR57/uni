public class UsaLibro {
	
	public static void main(String[] args){
		Libro libro1 = new Libro("Collodi","Pinocchio", 2);
		Libro libro2 = new Libro("Manzoni", "I Promessi sposi", 3);
		System.out.println("Libro 1: ");
		libro1.stampa();
		System.out.println("Copie disponibili: " + libro1.disponibili());
		System.out.println("Libro 2: ");
		libro2.stampa();
		System.out.println("Copie disponibili: " + libro2.disponibili());
		System.out.println("Chiedo una copia di Pinocchio in prestito");
		libro1.presta();
		System.out.println("Ora la disponibilita\' e\' di " + libro1.disponibili() + " copie.");
		System.out.println("Mentre la disponibilita\' dei Promessi sposi rimane " + libro2.disponibili() + " copie.");
		libro1.presta();
		System.out.println("Dopo un altro prestito la disponibilit� � di " + libro1.disponibili() + " copie");
		System.out.println("Se provo a chiedere il libro in prestito ottengo:");
		libro1.presta();
		System.out.println("Mentre posso prendere una copia de I promessi Sposi");
		libro2.presta();
		System.out.println("Adesso ne rimangono " + libro2.disponibili() + " copie disponibili");
		System.out.println("Meglio restituire Pinocchio");
		libro1.restituisci();
		libro1.restituisci();
		System.out.println("Ci sono " + libro1.disponibili() + " copie di Pinocchio, proviano a restituirene un\'altra copia");
		libro1.restituisci();
	}
}