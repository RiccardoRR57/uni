public class Libro {

	private String autore;
	private String titolo;
	private int copie;
	private int copieDisponibili;
	
	/** Il Costruttore del metodo: sostituisce init() **/
	public Libro(String autore, String titolo, int copie){
		this.autore = autore;
		this.titolo = titolo;
		this.copie = copie;
		this.copieDisponibili = copie;
	}
	/** Metodo che restituisce il numero di copie disponibili **/
	public int disponibili(){
		return copieDisponibili;
	}
	/** Metodo che permette di prestare una copia del libro sul quale � stato invocato **/
	public void presta(){
		if(copieDisponibili>0)
			copieDisponibili--;
		else
			System.out.println("Errore: non ci sono copie disponibili");
	}
	/** Metodo che permette di restituire una copia del libro **/
	public void restituisci(){
		if(copieDisponibili < copie)
			copieDisponibili++;
		else
			System.out.println("C\'e\' qualcosa che non va!\n");
	}
	/** Metodo per stampare i dettagli sul libro **/
	public void stampa(){
		System.out.println("Titolo:" + titolo + ", Autore: " + autore);
	}
}
