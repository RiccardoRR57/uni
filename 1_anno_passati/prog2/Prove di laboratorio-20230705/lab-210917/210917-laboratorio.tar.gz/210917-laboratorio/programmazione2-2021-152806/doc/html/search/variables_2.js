var searchData=
[
  ['orafine_55',['oraFine',['../structtipo__inf.html#a537cbc52437d292db3e4557e12421880',1,'tipo_inf']]],
  ['orainizio_56',['oraInizio',['../structtipo__inf.html#a36236882dfee7ec19ebd163e33fd8be1',1,'tipo_inf']]]
];
