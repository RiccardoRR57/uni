var searchData=
[
  ['delete_5felem_40',['delete_elem',['../liste_8cc.html#aa078cd7a67139b3780555bd5b9551938',1,'delete_elem(lista l, elem *e):&#160;liste.cc'],['../liste_8h.html#a2a9647a11daf84cb9eb6f418780840b4',1,'delete_elem(lista, elem *):&#160;liste.cc']]]
];
