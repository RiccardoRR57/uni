var searchData=
[
  ['quanti_48',['quanti',['../compito_8cc.html#a122e4028fbab5209682b5c2aa419790c',1,'compito.cc']]]
];
