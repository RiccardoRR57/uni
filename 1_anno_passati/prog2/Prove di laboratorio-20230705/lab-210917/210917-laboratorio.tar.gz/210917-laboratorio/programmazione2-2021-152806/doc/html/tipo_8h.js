var tipo_8h =
[
    [ "tipo_inf", "structtipo__inf.html", "structtipo__inf" ],
    [ "appuntamento", "tipo_8h.html#aaddd544d82cb9769e4e03d61dc926022", null ],
    [ "compare", "tipo_8h.html#abaf6df3b59219b4f9a01bceaa9a7ac65", null ],
    [ "copy", "tipo_8h.html#a5b601e34d40349d965e34c2dcc79ce1f", null ],
    [ "print", "tipo_8h.html#a613fc6e18b77c8dde2d91609c0599a1e", null ]
];