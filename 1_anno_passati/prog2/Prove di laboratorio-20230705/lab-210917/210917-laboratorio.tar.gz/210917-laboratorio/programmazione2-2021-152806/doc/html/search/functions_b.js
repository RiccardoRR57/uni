var searchData=
[
  ['tail_51',['tail',['../liste_8cc.html#a5b6a1f6fecd8fc74a45c077ae9bf8716',1,'tail(lista p):&#160;liste.cc'],['../liste_8h.html#ad586fc3b061e5c92b2e18ffc7e90b96a',1,'tail(lista):&#160;liste.cc']]]
];
