var files_dup =
[
    [ "compito.cc", "compito_8cc.html", "compito_8cc" ],
    [ "liste.cc", "liste_8cc.html", "liste_8cc" ],
    [ "liste.h", "liste_8h.html", "liste_8h" ],
    [ "tipo.cc", "tipo_8cc.html", "tipo_8cc" ],
    [ "tipo.h", "tipo_8h.html", "tipo_8h" ]
];