var searchData=
[
  ['insert_5felem_42',['insert_elem',['../liste_8cc.html#a9401a70af33fb357eef32ef1a58ba979',1,'insert_elem(lista l, elem *e):&#160;liste.cc'],['../liste_8h.html#a2f235f57d084db5bd8d8c6ea6282eb8d',1,'insert_elem(lista, elem *):&#160;liste.cc']]]
];
