var tipo_8cc =
[
    [ "compare", "tipo_8cc.html#aca9696962783fbe612428ee7e991ce75", null ],
    [ "copy", "tipo_8cc.html#a780d7635e64a79222bb506ed6e9f72f0", null ],
    [ "print", "tipo_8cc.html#af5392bbac3bda30b7b5c2e033f7878a4", null ]
];