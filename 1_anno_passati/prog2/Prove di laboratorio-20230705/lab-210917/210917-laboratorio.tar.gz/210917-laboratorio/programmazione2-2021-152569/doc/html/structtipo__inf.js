var structtipo__inf =
[
    [ "data", "structtipo__inf.html#ade459bd01129385e61f56f39739d2a13", null ],
    [ "descr", "structtipo__inf.html#a97a42b5f9c3af10219647bf7cee08854", null ],
    [ "oraf", "structtipo__inf.html#ad2b02884ca7cf9aa524982362d4e5d10", null ],
    [ "orai", "structtipo__inf.html#ae2d4843e645d9f311239693304a1f610", null ]
];