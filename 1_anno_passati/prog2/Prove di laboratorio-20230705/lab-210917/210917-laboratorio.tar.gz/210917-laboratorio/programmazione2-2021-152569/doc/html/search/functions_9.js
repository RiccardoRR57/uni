var searchData=
[
  ['search_46',['search',['../liste_8cc.html#a8774e878eabc2ae8c7240efa05918138',1,'search(lista l, tipo_inf v):&#160;liste.cc'],['../liste_8h.html#af4cc078b390c4b70e94bf94f5aa7bd44',1,'search(lista, tipo_inf):&#160;liste.cc']]],
  ['stampa_47',['stampa',['../compito_8cc.html#a07e15f0019f90fbd94812a723766a51b',1,'compito.cc']]]
];
