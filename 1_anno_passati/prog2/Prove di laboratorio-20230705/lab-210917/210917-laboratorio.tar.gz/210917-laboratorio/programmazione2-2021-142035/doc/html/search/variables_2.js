var searchData=
[
  ['ora_5ff_52',['ora_f',['../structtipo__inf.html#a55d339d6349aa5646b2f31c7716718c3',1,'tipo_inf']]],
  ['ora_5fi_53',['ora_i',['../structtipo__inf.html#ac21ec8f0f8a2aa6f1004a94bd67304de',1,'tipo_inf']]]
];
