var searchData=
[
  ['compito_2ecc_30',['compito.cc',['../compito_8cc.html',1,'']]]
];
