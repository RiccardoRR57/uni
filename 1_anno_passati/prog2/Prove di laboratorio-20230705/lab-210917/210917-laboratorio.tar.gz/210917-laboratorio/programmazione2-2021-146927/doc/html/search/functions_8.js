var searchData=
[
  ['quanti_45',['quanti',['../compito_8cc.html#aedfdb0dd546e4e3beca3163f9eb84fdf',1,'compito.cc']]]
];
