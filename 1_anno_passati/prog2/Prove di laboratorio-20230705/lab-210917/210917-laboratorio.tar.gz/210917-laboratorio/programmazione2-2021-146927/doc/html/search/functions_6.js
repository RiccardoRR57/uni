var searchData=
[
  ['new_5felem_42',['new_elem',['../liste_8cc.html#acb78e072c91c3657d5f988771452891e',1,'new_elem(tipo_inf inf):&#160;liste.cc'],['../liste_8h.html#a94b072bf9ce0f93fbaaf62f4c4ba7783',1,'new_elem(tipo_inf):&#160;liste.cc']]]
];
