var searchData=
[
  ['agenda_35',['agenda',['../compito_8cc.html#a12424dd76d1acf0724d65d3d341c9382',1,'compito.cc']]]
];
