var searchData=
[
  ['compare_36',['compare',['../tipo_8cc.html#a4ea6db4e528c565db72752225a20862b',1,'compare(tipo_inf t1, tipo_inf t2):&#160;tipo.cc'],['../tipo_8h.html#abaf6df3b59219b4f9a01bceaa9a7ac65',1,'compare(tipo_inf, tipo_inf):&#160;tipo.cc']]],
  ['copy_37',['copy',['../tipo_8cc.html#a0f4d753e08195629903f2df5fdfdaff8',1,'copy(tipo_inf &amp;t1, tipo_inf t2):&#160;tipo.cc'],['../tipo_8h.html#a5b601e34d40349d965e34c2dcc79ce1f',1,'copy(tipo_inf &amp;, tipo_inf):&#160;tipo.cc']]]
];
