/*******************************/
/* HEADER MODULO "tipo" */
/*******************************/



typedef int tipo_inf;

int compare(tipo_inf,tipo_inf);
void copy(tipo_inf&,tipo_inf);
void print(tipo_inf);
